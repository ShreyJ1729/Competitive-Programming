//Solution - UIL Region 2019
import static java.lang.System.out;
public class Andy {

	public static void main(String[] args) {
		out.println("   ooooo+");
		out.println("  ooooo++");
		out.println(" ooooo+++");
		out.println("ooooo++++");
		out.println("xxxxx++++");
		out.println("xxxxx+++");
		out.println("xxxxx++");
		out.println("xxxxx+ ");
	}
}
